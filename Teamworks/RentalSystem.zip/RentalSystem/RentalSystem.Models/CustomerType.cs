﻿namespace RentalSystem.Models
{
    public enum CustomerType
    {
        Regular, Thief, MachineBreak, NotComplyDeadline, VIPClient, FamilyFriend
    }
}