﻿namespace RentalSystem.Models
{
    public interface IArchivable
    {
        void Archive();
    }
}